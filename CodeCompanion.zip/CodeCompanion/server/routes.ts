import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateAIResponse } from "./gemini";
import { insertMessageSchema, insertConversationSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/conversations", async (req, res) => {
    try {
      const validatedData = insertConversationSchema.parse(req.body);
      const conversation = await storage.createConversation(validatedData);
      res.json(conversation);
    } catch (error) {
      res.status(400).json({ error: "Dados inválidos" });
    }
  });

  app.get("/api/conversations", async (req, res) => {
    try {
      const conversations = await storage.getAllConversations();
      res.json(conversations);
    } catch (error) {
      res.status(500).json({ error: "Erro ao buscar conversas" });
    }
  });

  app.get("/api/conversations/:id/messages", async (req, res) => {
    try {
      const messages = await storage.getMessagesByConversation(req.params.id);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Erro ao buscar mensagens" });
    }
  });

  app.post("/api/messages", async (req, res) => {
    try {
      const validatedData = insertMessageSchema.parse(req.body);
      
      if (validatedData.role !== "user") {
        return res.status(400).json({ error: "Apenas mensagens de usuário podem ser enviadas" });
      }

      const userMessage = await storage.createMessage(validatedData);

      const conversationMessages = await storage.getMessagesByConversation(validatedData.conversationId);
      const history = conversationMessages
        .filter(msg => msg.id !== userMessage.id)
        .map(msg => ({
          role: msg.role,
          content: msg.content,
        }));

      const aiResponseText = await generateAIResponse(validatedData.content, history);

      const aiMessage = await storage.createMessage({
        conversationId: validatedData.conversationId,
        role: "assistant",
        content: aiResponseText,
      });

      res.json({
        userMessage,
        aiMessage,
      });
    } catch (error: any) {
      console.error("Erro ao processar mensagem:", error);
      res.status(500).json({ error: error.message || "Erro ao processar mensagem" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
