import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;

if (!apiKey) {
  throw new Error("GEMINI_API_KEY não está configurada");
}

const ai = new GoogleGenAI({ apiKey });

const systemPrompt = `Você é um assistente de programação especializado chamado CodeAssist AI. Você é expert em múltiplas linguagens de programação incluindo:
- LUA
- JavaScript / Node.js
- Java
- Python
- C/C++
- Go
- Rust
- TypeScript
- E muitas outras

Suas responsabilidades:
1. Fornecer explicações claras e concisas sobre conceitos de programação
2. Ajudar a debugar código e identificar problemas
3. Sugerir melhores práticas e otimizações
4. Escrever exemplos de código bem comentados
5. Comparar diferentes abordagens e linguagens quando relevante

Diretrizes de resposta:
- Use markdown para formatar suas respostas
- Sempre coloque código em blocos de código com a linguagem especificada (exemplo: \`\`\`javascript)
- Seja didático e paciente
- Forneça exemplos práticos sempre que possível
- Explique não apenas "o que" mas também "por que"
- Responda em português brasileiro

Mantenha suas respostas focadas, práticas e educativas.`;

export async function generateAIResponse(userMessage: string, conversationHistory: Array<{ role: string; content: string }> = []): Promise<string> {
  try {
    const contents = [
      ...conversationHistory.map(msg => ({
        role: msg.role === "assistant" ? "model" : "user",
        parts: [{ text: msg.content }],
      })),
      {
        role: "user",
        parts: [{ text: userMessage }],
      }
    ];

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
      },
      contents,
    });

    return response.text || "Não foi possível gerar uma resposta.";
  } catch (error) {
    console.error("Erro ao gerar resposta da IA:", error);
    throw new Error("Não foi possível gerar uma resposta. Por favor, tente novamente.");
  }
}
