# Design Guidelines: AI Programming Assistant

## Design Approach
**System Selected**: Hybrid approach drawing from Linear's clean interface philosophy + VS Code's code-focused design patterns + ChatGPT's conversational flow

**Rationale**: This is a utility-focused programming tool where clarity, efficiency, and code readability are paramount. The design should feel familiar to developers while maintaining a modern, professional aesthetic.

---

## Typography System

**Font Families**:
- Interface Text: Inter (via Google Fonts CDN)
- Code Blocks: JetBrains Mono (via Google Fonts CDN)

**Hierarchy**:
- Page Title: 2xl, semibold
- Section Headers: xl, medium
- Chat Messages: base, normal
- Code Snippets: sm, normal (monospace)
- UI Labels: sm, medium
- Timestamps: xs, normal

---

## Layout System

**Spacing Primitives**: Use Tailwind units of **2, 4, 6, and 8** consistently
- Component padding: p-4, p-6
- Section spacing: gap-4, gap-6
- Message spacing: space-y-4
- Container margins: m-6, m-8

**Grid Structure**:
- Single column chat layout (max-w-4xl centered)
- Message bubbles: Full width with internal max-width constraints
- Code blocks: Full width within message container

---

## Core Layout Structure

### Header (Fixed Top)
- Height: h-16
- Layout: Flex row with space-between
- Elements: Logo/Title (left), New Chat button (right)
- Padding: px-6
- Border: Bottom border for separation

### Main Chat Area (Scrollable)
- Container: flex-1, overflow-y-auto
- Inner container: max-w-4xl, mx-auto, px-6
- Message spacing: space-y-6
- Padding: py-8

### Input Area (Fixed Bottom)
- Container: max-w-4xl, mx-auto, px-6, pb-6
- Input wrapper: Rounded container with border
- Layout: Flex row for input + send button
- Padding: p-4

---

## Component Library

### Message Bubbles

**User Messages**:
- Alignment: ml-auto, max-w-3xl
- Padding: p-4
- Border radius: rounded-2xl
- Typography: base, leading-relaxed

**AI Messages**:
- Alignment: mr-auto, max-w-3xl  
- Padding: p-4
- Border radius: rounded-2xl
- Typography: base, leading-relaxed
- Avatar: w-8 h-8 circle icon (programming symbol)

### Code Blocks
- Container: rounded-lg, my-4
- Header bar: px-4, py-2, rounded-t-lg (language label + copy button)
- Code area: p-4, rounded-b-lg
- Font: JetBrains Mono, text-sm
- Overflow: overflow-x-auto
- Use Prism.js or Highlight.js for syntax highlighting

### Input Field
- Height: min-h-12, max-h-48 (auto-expand)
- Padding: px-4, py-3
- Border radius: rounded-xl
- Typography: base
- Placeholder: "Pergunte sobre programação..."

### Buttons

**Primary (Send)**:
- Size: w-10 h-10
- Border radius: rounded-lg
- Icon: Heroicons paper-airplane or arrow-up
- Position: Absolute right in input container

**Secondary (New Chat)**:
- Padding: px-4, py-2
- Border radius: rounded-lg
- Typography: sm, medium
- Icon: Heroicons plus

### Conversation History Sidebar (Optional Toggle)
- Width: w-64 on desktop, full overlay on mobile
- Padding: p-4
- List items: p-3, rounded-lg, space-y-2
- Item typography: sm, truncate

---

## Icons
**Library**: Heroicons (via CDN)

**Usage**:
- Send message: paper-airplane or arrow-up
- New chat: plus
- Copy code: clipboard-document
- AI avatar: cpu-chip or sparkles
- Menu toggle: bars-3
- Settings: cog-6-tooth

---

## Component Patterns

### Welcome State (Empty Chat)
- Centered container: flex flex-col items-center justify-center, min-h-96
- Icon: Large AI icon (w-16 h-16)
- Title: text-2xl, font-semibold, mt-4
- Description: text-base, mt-2, max-w-md, text-center
- Example prompts: Grid of 2-3 suggestion cards (p-4, rounded-xl, border)

### Loading State
- Typing indicator: Three animated dots
- Container: Same as AI message bubble
- Animation: Pulse effect on dots

### Code Block Header
- Layout: Flex justify-between
- Left: Language label (text-xs, uppercase)
- Right: Copy button (text-xs, hover effect)
- Padding: px-4, py-2

### Timestamp Display
- Position: Below message bubble
- Typography: text-xs
- Alignment: Matches message alignment

---

## Responsive Behavior

**Desktop (lg:)**:
- Chat container: max-w-4xl
- Messages: Comfortable spacing (space-y-6)
- Input: Fixed at bottom with breathing room

**Tablet (md:)**:
- Chat container: max-w-2xl
- Reduce horizontal padding to px-4

**Mobile (base)**:
- Full width minus minimal padding (px-3)
- Input: Sticky bottom with safe area padding
- Code blocks: Horizontal scroll with proper touch handling
- No sidebar by default (toggle overlay)

---

## Accessibility

- Semantic HTML: Use `<main>`, `<article>` for messages, `<form>` for input
- ARIA labels: "Send message", "Start new conversation", "Copy code"
- Keyboard navigation: Tab through interactive elements
- Focus states: Visible outline on all interactive elements
- Screen reader support: Announce new messages

---

## Performance Considerations

- Virtualize message list for long conversations (react-window or similar)
- Lazy load syntax highlighting for off-screen code blocks
- Debounce input auto-resize calculations
- Code block copy uses clipboard API efficiently

---

## No Images Required
This application is purely functional and doesn't require hero images or decorative imagery. The focus is on clean, efficient code presentation and conversation flow.