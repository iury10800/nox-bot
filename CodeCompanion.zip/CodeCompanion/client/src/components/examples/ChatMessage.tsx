import ChatMessage from "../ChatMessage";

export default function ChatMessageExample() {
  return (
    <div className="space-y-6 p-6 bg-background">
      <ChatMessage
        role="user"
        content="Como criar uma função recursiva em Python?"
        timestamp={new Date()}
      />
      
      <ChatMessage
        role="assistant"
        content={`Aqui está um exemplo de função recursiva em Python:\n\n\`\`\`python\ndef fatorial(n):\n    if n == 0 or n == 1:\n        return 1\n    return n * fatorial(n - 1)\n\nresultado = fatorial(5)\nprint(f"5! = {resultado}")\n\`\`\`\n\nUma função recursiva é uma função que **chama a si mesma**. Componentes importantes:\n\n1. **Caso base**: Condição de parada (n == 0 ou n == 1)\n2. **Chamada recursiva**: A função chama a si mesma com um valor diferente\n3. **Progresso**: Cada chamada deve se aproximar do caso base`}
        timestamp={new Date()}
      />
    </div>
  );
}
