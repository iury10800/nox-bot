import ChatPage from "../../pages/ChatPage";
import { ThemeProvider } from "@/hooks/use-theme";

export default function ChatPageExample() {
  return (
    <ThemeProvider>
      <ChatPage />
    </ThemeProvider>
  );
}
