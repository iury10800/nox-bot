import WelcomeScreen from "../WelcomeScreen";

export default function WelcomeScreenExample() {
  const handleSuggestionClick = (suggestion: string) => {
    console.log("Sugestão clicada:", suggestion);
  };

  return (
    <div className="min-h-screen bg-background">
      <WelcomeScreen onSuggestionClick={handleSuggestionClick} />
    </div>
  );
}
