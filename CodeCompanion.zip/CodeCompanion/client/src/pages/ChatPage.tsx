import { useState, useRef, useEffect } from "react";
import { Plus } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import ChatMessage from "@/components/ChatMessage";
import ChatInput from "@/components/ChatInput";
import WelcomeScreen from "@/components/WelcomeScreen";
import LoadingIndicator from "@/components/LoadingIndicator";
import ThemeToggle from "@/components/ThemeToggle";
import { apiRequest } from "@/lib/queryClient";
import type { Message } from "@shared/schema";

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const createConversation = async () => {
    const response = await apiRequest("POST", "/api/conversations", { title: "Nova Conversa" });
    return response.json();
  };

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      let convId = conversationId;
      
      if (!convId) {
        const newConv = await createConversation();
        convId = newConv.id;
        setConversationId(convId);
      }

      const response = await apiRequest("POST", "/api/messages", {
        conversationId: convId,
        role: "user",
        content,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Erro ao enviar mensagem");
      }

      return response.json();
    },
    onSuccess: (data) => {
      setMessages((prev) => [...prev, data.userMessage, data.aiMessage]);
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = (content: string) => {
    sendMessageMutation.mutate(content);
  };

  const handleNewChat = () => {
    setMessages([]);
    setConversationId(null);
  };

  const handleSuggestionClick = (suggestion: string) => {
    handleSendMessage(suggestion);
  };

  return (
    <div className="flex flex-col h-screen bg-background">
      <header className="flex items-center justify-between h-16 px-6 border-b border-border flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary text-primary-foreground">
            <span className="text-sm font-bold">CA</span>
          </div>
          <h1 className="text-xl font-semibold" data-testid="text-app-title">
            CodeAssist AI
          </h1>
        </div>
        
        <div className="flex items-center gap-2">
          {messages.length > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleNewChat}
              data-testid="button-new-chat"
            >
              <Plus className="w-4 h-4 mr-2" />
              Nova Conversa
            </Button>
          )}
          <ThemeToggle />
        </div>
      </header>

      <main className="flex-1 overflow-y-auto">
        {messages.length === 0 ? (
          <WelcomeScreen onSuggestionClick={handleSuggestionClick} />
        ) : (
          <div className="w-full max-w-4xl mx-auto px-6 py-8">
            <div className="space-y-6">
              {messages.map((message) => (
                <ChatMessage
                  key={message.id}
                  role={message.role as "user" | "assistant"}
                  content={message.content}
                  timestamp={message.createdAt}
                />
              ))}
              {sendMessageMutation.isPending && <LoadingIndicator />}
              <div ref={messagesEndRef} />
            </div>
          </div>
        )}
      </main>

      <div className="flex-shrink-0">
        <ChatInput
          onSend={handleSendMessage}
          disabled={sendMessageMutation.isPending}
        />
      </div>
    </div>
  );
}
