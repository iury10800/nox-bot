# CodeAssist AI - Programming Assistant

## Overview

CodeAssist AI is a conversational programming assistant web application that provides expert help across multiple programming languages including LUA, JavaScript/Node.js, Java, Python, C/C++, Go, Rust, and TypeScript. The application features a chat-based interface where users can ask programming questions, get code examples, debugging help, and learn best practices.

The system is built as a full-stack TypeScript application with a React frontend and Express backend, utilizing Google's Gemini AI for intelligent programming assistance.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Tooling:**
- **React 18** with TypeScript for type-safe UI development
- **Vite** as the build tool and development server
- **Wouter** for lightweight client-side routing
- **TanStack Query** (React Query) for server state management and API caching

**UI Component System:**
- **shadcn/ui** components based on Radix UI primitives
- **Tailwind CSS** for utility-first styling with custom design tokens
- Component library follows the "new-york" style variant
- Design philosophy draws from Linear's clean interface, VS Code's code-focused patterns, and ChatGPT's conversational flow

**State Management:**
- Local component state for UI interactions
- React Query for server-side data caching and synchronization
- Context API for theme management (light/dark mode)
- No global state management library (Redux/Zustand) - keeping state local and focused

**Styling Approach:**
- CSS variables for theming (supporting light/dark modes)
- Consistent spacing scale using Tailwind units (2, 4, 6, 8)
- Custom font stack: Inter for UI text, JetBrains Mono for code blocks
- Responsive design with mobile-first breakpoints

### Backend Architecture

**Server Framework:**
- **Express.js** with TypeScript
- RESTful API design pattern
- JSON-based request/response format

**Storage Strategy:**
- **In-Memory Storage** (MemStorage class) for development/demo purposes
- Schema designed for PostgreSQL using Drizzle ORM
- Future-ready for database migration without API changes
- Storage abstraction through IStorage interface allows easy swapping

**Data Models:**
- **Users**: Basic user records (username, password)
- **Conversations**: Chat session containers with titles and timestamps
- **Messages**: Individual chat messages with role (user/assistant), content, and conversation association

**API Design:**
- `POST /api/conversations` - Create new conversation
- `GET /api/conversations` - List all conversations
- `GET /api/conversations/:id/messages` - Get conversation history
- `POST /api/messages` - Send user message and receive AI response

### AI Integration

**Provider:**
- **Google Gemini AI** via `@google/genai` SDK
- Configured with specialized system prompt for programming assistance
- Supports conversational context with message history

**Conversation Flow:**
1. User sends message to `/api/messages` endpoint
2. Backend retrieves conversation history from storage
3. History + new message sent to Gemini AI
4. AI response stored as assistant message
5. Both user and assistant messages returned to frontend
6. Frontend updates chat UI with streaming-like message display

**Response Formatting:**
- AI responses use Markdown format
- Code blocks specified with language tags for syntax highlighting
- Portuguese Brazilian (pt-BR) language for responses

### Build & Deployment

**Development:**
- TypeScript compilation with `tsx` for hot-reloading
- Vite dev server with HMR (Hot Module Replacement)
- Concurrent frontend and backend development

**Production Build:**
- Vite bundles frontend to `dist/public`
- esbuild bundles backend to `dist/index.js`
- Static file serving from Express
- Single deployment artifact

**Environment Variables:**
- `DATABASE_URL` - PostgreSQL connection string (required for production)
- `GEMINI_API_KEY` - Google Gemini API key (required)
- `NODE_ENV` - Environment mode (development/production)

### Code Quality & Type Safety

**TypeScript Configuration:**
- Strict mode enabled for maximum type safety
- Path aliases for clean imports (`@/`, `@shared/`)
- Shared types between frontend and backend via `shared/` directory
- No emit compilation for development (handled by runtime transpilers)

**Validation:**
- **Zod** schemas for runtime validation
- Drizzle-Zod integration for automatic schema validation
- Type-safe API contracts between client and server

## External Dependencies

### AI Services
- **Google Gemini AI** - Primary AI model for programming assistance
  - Requires `GEMINI_API_KEY` environment variable
  - Handles conversation context and code generation
  - Configured with programming-specific system prompts

### Database
- **PostgreSQL** via `@neondatabase/serverless`
  - Designed for but not yet implemented (using in-memory storage)
  - Drizzle ORM ready for migration
  - Schema defined in `shared/schema.ts`
  - Migrations directory configured at `./migrations`

### UI Component Libraries
- **Radix UI** - Accessible, unstyled component primitives
- **Tailwind CSS** - Utility-first CSS framework
- **shadcn/ui** - Pre-built component library
- **React Markdown** with `remark-gfm` for Markdown rendering
- **React Syntax Highlighter** with Prism themes for code display

### Development Tools
- **Replit Vite Plugins** - Development experience enhancements (cartographer, dev banner, runtime error overlay)
- **Drizzle Kit** - Database schema management and migrations

### Authentication
- Currently not implemented
- User schema exists but no authentication middleware
- Future implementation would likely use session-based auth with `connect-pg-simple` (already in dependencies)

### Fonts
- **Google Fonts CDN** - Inter, JetBrains Mono, Geist Mono, DM Sans, Fira Code, Architects Daughter
- Loaded via HTML link tags for optimal caching