import { useState, useRef, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import ChatMessage from "@/components/ChatMessage";
import ChatInput from "@/components/ChatInput";
import WelcomeScreen from "@/components/WelcomeScreen";
import LoadingIndicator from "@/components/LoadingIndicator";
import ThemeToggle from "@/components/ThemeToggle";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Message } from "@shared/schema";

export default function ChatPage() {
  const [conversationId, setConversationId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const { data: messages = [] } = useQuery<Message[]>({
    queryKey: ["/api/conversations", conversationId, "messages"],
    queryFn: async () => {
      if (!conversationId) return [];
      const response = await fetch(`/api/conversations/${conversationId}/messages`);
      if (!response.ok) throw new Error("Failed to fetch messages");
      return response.json();
    },
    enabled: !!conversationId,
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const createConversation = async () => {
    const firstMessage = "Nova Conversa";
    const response = await apiRequest("POST", "/api/conversations", { title: firstMessage });
    const data = await response.json();
    queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
    return data;
  };

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      let convId = conversationId;
      
      if (!convId) {
        const newConv = await createConversation();
        convId = newConv.id;
        setConversationId(convId);
      }

      const response = await apiRequest("POST", "/api/messages", {
        conversationId: convId,
        role: "user",
        content,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Erro ao enviar mensagem");
      }

      return response.json();
    },
    onSuccess: (data) => {
      const convId = data.userMessage.conversationId;
      setConversationId(convId);
      queryClient.invalidateQueries({ 
        queryKey: ["/api/conversations", convId, "messages"] 
      });
      queryClient.invalidateQueries({ 
        queryKey: ["/api/conversations"] 
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = (content: string) => {
    sendMessageMutation.mutate(content);
  };

  const handleNewChat = () => {
    if (conversationId) {
      queryClient.removeQueries({ 
        queryKey: ["/api/conversations", conversationId, "messages"] 
      });
    }
    setConversationId(null);
  };

  const handleConversationSelect = (id: string) => {
    setConversationId(id);
  };

  const handleSuggestionClick = (suggestion: string) => {
    handleSendMessage(suggestion);
  };

  return (
    <>
      <AppSidebar
        currentConversationId={conversationId}
        onConversationSelect={handleConversationSelect}
        onNewChat={handleNewChat}
      />
      <div className="flex flex-col flex-1">
        <header className="flex items-center justify-between h-16 px-6 border-b border-border flex-shrink-0">
          <div className="flex items-center gap-3">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary text-primary-foreground">
              <span className="text-sm font-bold">SN</span>
            </div>
            <h1 className="text-xl font-semibold" data-testid="text-app-title">
              Spectrum Nexus IA
            </h1>
          </div>
          
          <ThemeToggle />
        </header>

        <main className="flex-1 overflow-y-auto">
          {messages.length === 0 ? (
            <WelcomeScreen onSuggestionClick={handleSuggestionClick} />
          ) : (
            <div className="w-full max-w-4xl mx-auto px-6 py-8">
              <div className="space-y-6">
                {messages.map((message) => (
                  <ChatMessage
                    key={message.id}
                    role={message.role as "user" | "assistant"}
                    content={message.content}
                    timestamp={message.createdAt}
                  />
                ))}
                {sendMessageMutation.isPending && <LoadingIndicator />}
                <div ref={messagesEndRef} />
              </div>
            </div>
          )}
        </main>

        <div className="flex-shrink-0">
          <ChatInput
            onSend={handleSendMessage}
            disabled={sendMessageMutation.isPending}
          />
        </div>
      </div>
    </>
  );
}
