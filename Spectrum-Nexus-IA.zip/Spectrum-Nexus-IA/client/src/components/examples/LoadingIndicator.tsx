import LoadingIndicator from "../LoadingIndicator";

export default function LoadingIndicatorExample() {
  return (
    <div className="p-6 bg-background">
      <LoadingIndicator />
    </div>
  );
}
