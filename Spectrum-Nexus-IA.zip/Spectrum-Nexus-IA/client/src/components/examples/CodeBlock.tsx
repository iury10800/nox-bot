import CodeBlock from "../CodeBlock";
import { ThemeProvider } from "@/hooks/use-theme";

export default function CodeBlockExample() {
  return (
    <ThemeProvider>
      <div className="p-6 bg-background">
        <CodeBlock
          language="javascript"
          code={`function fibonacci(n) {
  if (n <= 1) return n;
  return fibonacci(n - 1) + fibonacci(n - 2);
}

console.log(fibonacci(10));`}
        />
        
        <CodeBlock
          language="python"
          code={`def quicksort(arr):
    if len(arr) <= 1:
        return arr
    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    return quicksort(left) + middle + quicksort(right)`}
        />
      </div>
    </ThemeProvider>
  );
}
