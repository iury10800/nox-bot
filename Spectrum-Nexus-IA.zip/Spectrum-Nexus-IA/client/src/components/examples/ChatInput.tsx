import ChatInput from "../ChatInput";

export default function ChatInputExample() {
  const handleSend = (message: string) => {
    console.log("Mensagem enviada:", message);
  };

  return (
    <div className="p-6 bg-background">
      <ChatInput onSend={handleSend} />
    </div>
  );
}
