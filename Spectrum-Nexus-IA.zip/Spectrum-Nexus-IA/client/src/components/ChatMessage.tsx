import { useState, useEffect } from "react";
import { Cpu, User, Volume2, VolumeX } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import CodeBlock from "./CodeBlock";
import aiAvatar from "@assets/generated_images/Spectrum_Nexus_AI_Avatar_396a29da.png";

interface ChatMessageProps {
  role: "user" | "assistant";
  content: string;
  timestamp?: Date;
}

export default function ChatMessage({ role, content, timestamp }: ChatMessageProps) {
  const isUser = role === "user";
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voicesLoaded, setVoicesLoaded] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if ('speechSynthesis' in window) {
      const loadVoices = () => {
        const voices = window.speechSynthesis.getVoices();
        if (voices.length > 0) {
          setVoicesLoaded(true);
        }
      };

      loadVoices();
      
      if (window.speechSynthesis.onvoiceschanged !== undefined) {
        window.speechSynthesis.onvoiceschanged = loadVoices;
      }
    }
  }, []);

  const extractTextFromMarkdown = (markdown: string): string => {
    return markdown
      .replace(/```[\s\S]*?```/g, '')
      .replace(/`[^`]+`/g, '')
      .replace(/#{1,6}\s/g, '')
      .replace(/\*\*([^*]+)\*\*/g, '$1')
      .replace(/\*([^*]+)\*/g, '$1')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      .replace(/^\s*[-*+]\s/gm, '')
      .replace(/^\s*\d+\.\s/gm, '')
      .trim();
  };

  const handleSpeak = () => {
    if (!('speechSynthesis' in window)) {
      toast({
        title: "Recurso não disponível",
        description: "A funcionalidade de voz não é suportada neste navegador. Abra o aplicativo em Chrome, Edge ou Safari para usar este recurso.",
        variant: "destructive",
      });
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const textToSpeak = extractTextFromMarkdown(content);
    
    if (!textToSpeak) {
      toast({
        title: "Nenhum texto encontrado",
        description: "Esta mensagem não contém texto para ser lido.",
      });
      return;
    }

    try {
      const voices = window.speechSynthesis.getVoices();
      const ptBRVoice = voices.find(voice => voice.lang.startsWith('pt-BR')) || 
                        voices.find(voice => voice.lang.startsWith('pt')) ||
                        voices[0];

      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      
      if (ptBRVoice) {
        utterance.voice = ptBRVoice;
      }
      
      utterance.lang = 'pt-BR';
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      
      utterance.onstart = () => {
        setIsSpeaking(true);
      };
      
      utterance.onend = () => {
        setIsSpeaking(false);
      };
      
      utterance.onerror = (event) => {
        console.error('Erro ao falar:', event);
        setIsSpeaking(false);
        toast({
          title: "Erro ao reproduzir voz",
          description: "Não foi possível reproduzir o áudio. Tente abrir em outro navegador.",
          variant: "destructive",
        });
      };

      window.speechSynthesis.speak(utterance);
    } catch (error) {
      console.error('Erro ao tentar falar:', error);
      setIsSpeaking(false);
      toast({
        title: "Erro ao reproduzir voz",
        description: "Ocorreu um erro ao tentar reproduzir o áudio.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className={`flex gap-4 ${isUser ? "justify-end" : "justify-start"}`} data-testid={`message-${role}`}>
      {!isUser && (
        <Avatar className="w-8 h-8 flex-shrink-0" data-testid="avatar-assistant">
          <AvatarImage src={aiAvatar} alt="Spectrum Nexus IA" />
          <AvatarFallback className="bg-primary text-primary-foreground">
            <Cpu className="w-4 h-4" />
          </AvatarFallback>
        </Avatar>
      )}
      
      <div className={`flex flex-col ${isUser ? "items-end" : "items-start"} max-w-3xl`}>
        <div className="relative group w-full">
          {!isUser && (
            <Button
              size="icon"
              variant="ghost"
              className="absolute -bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity h-7 w-7 z-10"
              onClick={handleSpeak}
              data-testid="button-speak-message"
            >
              {isSpeaking ? (
                <VolumeX className="w-4 h-4" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </Button>
          )}
          <div
            className={`rounded-2xl px-4 py-3 ${
              isUser
                ? "bg-primary text-primary-foreground"
                : "bg-card border border-card-border"
            }`}
            data-testid={`message-content-${role}`}
          >
          {isUser ? (
            <p className="text-base leading-relaxed whitespace-pre-wrap">{content}</p>
          ) : (
            <div className="prose prose-sm dark:prose-invert max-w-none">
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={{
                  code({ className, children, ...props }) {
                    const match = /language-(\w+)/.exec(className || "");
                    const language = match ? match[1] : "";
                    const codeContent = String(children).replace(/\n$/, "");
                    const isInline = !className;

                    if (!isInline && language) {
                      return (
                        <CodeBlock language={language} code={codeContent} />
                      );
                    }

                    return (
                      <code
                        className="bg-muted px-1.5 py-0.5 rounded text-sm font-mono"
                        {...props}
                      >
                        {children}
                      </code>
                    );
                  },
                  p({ children }) {
                    return <p className="text-base leading-relaxed mb-3 last:mb-0">{children}</p>;
                  },
                  ul({ children }) {
                    return <ul className="list-disc pl-6 mb-3 space-y-1">{children}</ul>;
                  },
                  ol({ children }) {
                    return <ol className="list-decimal pl-6 mb-3 space-y-1">{children}</ol>;
                  },
                  li({ children }) {
                    return <li className="text-base">{children}</li>;
                  },
                  h1({ children }) {
                    return <h1 className="text-xl font-semibold mb-2 mt-4 first:mt-0">{children}</h1>;
                  },
                  h2({ children }) {
                    return <h2 className="text-lg font-semibold mb-2 mt-3 first:mt-0">{children}</h2>;
                  },
                  h3({ children }) {
                    return <h3 className="text-base font-semibold mb-2 mt-3 first:mt-0">{children}</h3>;
                  },
                }}
              >
                {content}
              </ReactMarkdown>
            </div>
          )}
          </div>
        </div>
        
        {timestamp && (
          <span className="text-xs text-muted-foreground mt-1" data-testid="message-timestamp">
            {new Date(timestamp).toLocaleTimeString("pt-BR", {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </span>
        )}
      </div>

      {isUser && (
        <Avatar className="w-8 h-8 flex-shrink-0" data-testid="avatar-user">
          <AvatarFallback className="bg-secondary text-secondary-foreground">
            <User className="w-4 h-4" />
          </AvatarFallback>
        </Avatar>
      )}
    </div>
  );
}
