import { MessageSquare, Plus } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import type { Conversation } from "@shared/schema";

interface AppSidebarProps {
  currentConversationId: string | null;
  onConversationSelect: (id: string) => void;
  onNewChat: () => void;
}

export function AppSidebar({ currentConversationId, onConversationSelect, onNewChat }: AppSidebarProps) {
  const { data: conversations = [] } = useQuery<Conversation[]>({
    queryKey: ["/api/conversations"],
  });

  const sortedConversations = [...conversations].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <Button
          onClick={onNewChat}
          className="w-full"
          data-testid="button-new-chat-sidebar"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nova Conversa
        </Button>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Histórico</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {sortedConversations.map((conversation) => (
                <SidebarMenuItem key={conversation.id}>
                  <SidebarMenuButton
                    onClick={() => onConversationSelect(conversation.id)}
                    isActive={currentConversationId === conversation.id}
                    data-testid={`conversation-item-${conversation.id}`}
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span className="truncate">{conversation.title}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
