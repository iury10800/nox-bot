import { Code2, Sparkles } from "lucide-react";
import { Card } from "@/components/ui/card";

interface WelcomeScreenProps {
  onSuggestionClick: (suggestion: string) => void;
}

const suggestions = [
  {
    title: "Explicar Conceito",
    question: "Como funcionam closures em JavaScript?",
    icon: Code2,
  },
  {
    title: "Debugar Código",
    question: "Por que meu código em Python está dando erro de indentação?",
    icon: Code2,
  },
  {
    title: "Melhores Práticas",
    question: "Quais são as melhores práticas para escrever código em Java?",
    icon: Sparkles,
  },
  {
    title: "Comparar Linguagens",
    question: "Qual a diferença entre LUA e JavaScript?",
    icon: Code2,
  },
];

export default function WelcomeScreen({ onSuggestionClick }: WelcomeScreenProps) {
  return (
    <div className="flex flex-col items-center justify-center min-h-96 px-6">
      <div className="flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
        <Sparkles className="w-8 h-8 text-primary" />
      </div>
      
      <h1 className="text-2xl font-semibold mb-2 text-center" data-testid="text-welcome-title">
        Spectrum Nexus IA
      </h1>
      
      <p className="text-base text-muted-foreground mb-8 max-w-md text-center" data-testid="text-welcome-description">
        Seu assistente de programação especializado em LUA, JAVA, Node.js, Python e muito mais.
        Faça uma pergunta para começar!
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 w-full max-w-2xl">
        {suggestions.map((suggestion, index) => (
          <Card
            key={index}
            className="p-4 hover-elevate active-elevate-2 cursor-pointer transition-all"
            onClick={() => onSuggestionClick(suggestion.question)}
            data-testid={`card-suggestion-${index}`}
          >
            <div className="flex items-start gap-3">
              <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary/10 flex-shrink-0">
                <suggestion.icon className="w-4 h-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-medium text-sm mb-1">{suggestion.title}</h3>
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {suggestion.question}
                </p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
