import { Cpu } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export default function LoadingIndicator() {
  return (
    <div className="flex gap-4 justify-start" data-testid="loading-indicator">
      <Avatar className="w-8 h-8 flex-shrink-0">
        <AvatarFallback className="bg-primary text-primary-foreground">
          <Cpu className="w-4 h-4" />
        </AvatarFallback>
      </Avatar>
      
      <div className="flex flex-col items-start max-w-3xl">
        <div className="rounded-2xl px-4 py-3 bg-card border border-card-border">
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
            <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
            <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
          </div>
        </div>
      </div>
    </div>
  );
}
